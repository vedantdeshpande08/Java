package com.library.repository;

import com.library.model.Book;

public class BookRepository extends FileRepository<Book> {

    public BookRepository(String filePath) {
        super(filePath, Book::toCsv, Book::fromCsv, Book::getId);
    }
}

package com.library.repository;

import com.library.model.Member;

public class MemberRepository extends FileRepository<Member> {

    public MemberRepository(String filePath) {
        super(filePath, Member::toCsv, Member::fromCsv, Member::getId);
    }
}

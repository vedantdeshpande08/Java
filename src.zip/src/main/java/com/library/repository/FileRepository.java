package com.library.repository;

import com.library.util.AppLogger;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Function;

/**
 * Generic, file-backed CRUD repository. Every concrete repository
 * (Book/Member/Transaction) plugs in its own CSV serializer/deserializer
 * and gets load/save/find/save-all behaviour for free.
 *
 * Records are kept in an in-memory LinkedHashMap for O(1) lookups
 * (performance requirement) and flushed to disk on every write so
 * data survives a restart (reliability requirement).
 *
 * @param <T> the entity type stored by this repository
 */
public abstract class FileRepository<T> {

    protected final Map<String, T> store = new LinkedHashMap<>();
    private final String filePath;
    private final Function<T, String> serializer;
    private final Function<String, T> deserializer;
    private final Function<T, String> idExtractor;

    protected FileRepository(String filePath, Function<T, String> serializer,
                              Function<String, T> deserializer, Function<T, String> idExtractor) {
        this.filePath = filePath;
        this.serializer = serializer;
        this.deserializer = deserializer;
        this.idExtractor = idExtractor;
        load();
    }

    private void load() {
        File file = new File(filePath);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                T entity = deserializer.apply(line);
                store.put(idExtractor.apply(entity), entity);
            }
        } catch (IOException | RuntimeException e) {
            // A corrupted data file should not crash the whole application on startup.
            AppLogger.error("Failed to load " + filePath + ": " + e.getMessage());
        }
    }

    protected void persist() {
        File file = new File(filePath);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        try (PrintWriter writer = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            for (T entity : store.values()) {
                writer.println(serializer.apply(entity));
            }
        } catch (IOException e) {
            AppLogger.error("Failed to save " + filePath + ": " + e.getMessage());
            throw new RuntimeException("Could not persist data to " + filePath, e);
        }
    }

    public Optional<T> findById(String id) {
        return Optional.ofNullable(store.get(id));
    }

    public List<T> findAll() {
        return new ArrayList<>(store.values());
    }

    public boolean existsById(String id) {
        return store.containsKey(id);
    }

    public void save(T entity) {
        store.put(idExtractor.apply(entity), entity);
        persist();
    }

    public void deleteById(String id) {
        store.remove(id);
        persist();
    }

    public int count() {
        return store.size();
    }
}

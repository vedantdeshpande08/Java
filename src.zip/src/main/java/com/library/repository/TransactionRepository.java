package com.library.repository;

import com.library.model.Transaction;

import java.util.List;
import java.util.stream.Collectors;

public class TransactionRepository extends FileRepository<Transaction> {

    public TransactionRepository(String filePath) {
        super(filePath, Transaction::toCsv, Transaction::fromCsv, Transaction::getId);
    }

    public List<Transaction> findByMemberId(String memberId) {
        return findAll().stream()
                .filter(t -> t.getMemberId().equals(memberId))
                .collect(Collectors.toList());
    }

    public List<Transaction> findByBookId(String bookId) {
        return findAll().stream()
                .filter(t -> t.getBookId().equals(bookId))
                .collect(Collectors.toList());
    }
}

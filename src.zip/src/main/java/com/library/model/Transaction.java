package com.library.model;

import java.time.LocalDate;

/**
 * Represents a single book-issue event and its eventual return.
 */
public class Transaction {

    private String id;
    private String bookId;
    private String memberId;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private LocalDate returnDate; // null while the book is still out
    private double fineAmount;
    private TransactionStatus status;

    public Transaction(String id, String bookId, String memberId, LocalDate issueDate,
                        LocalDate dueDate, LocalDate returnDate, double fineAmount,
                        TransactionStatus status) {
        this.id = id;
        this.bookId = bookId;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.fineAmount = fineAmount;
        this.status = status;
    }

    public String getId() { return id; }
    public String getBookId() { return bookId; }
    public String getMemberId() { return memberId; }
    public LocalDate getIssueDate() { return issueDate; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public double getFineAmount() { return fineAmount; }
    public void setFineAmount(double fineAmount) { this.fineAmount = fineAmount; }
    public TransactionStatus getStatus() { return status; }
    public void setStatus(TransactionStatus status) { this.status = status; }

    public String toCsv() {
        return String.join(",",
                id, bookId, memberId,
                issueDate.toString(), dueDate.toString(),
                returnDate == null ? "" : returnDate.toString(),
                String.valueOf(fineAmount), status.name());
    }

    public static Transaction fromCsv(String line) {
        String[] p = line.split(",", -1);
        return new Transaction(
                p[0], p[1], p[2],
                LocalDate.parse(p[3]),
                LocalDate.parse(p[4]),
                p[5].isEmpty() ? null : LocalDate.parse(p[5]),
                Double.parseDouble(p[6]),
                TransactionStatus.valueOf(p[7]));
    }

    @Override
    public String toString() {
        return String.format("[%s] Book:%s Member:%s Issued:%s Due:%s Returned:%s Fine:Rs.%.2f Status:%s",
                id, bookId, memberId, issueDate, dueDate,
                returnDate == null ? "-" : returnDate, fineAmount, status);
    }
}

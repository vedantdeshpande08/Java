package com.library.model;

/**
 * Represents a book title held by the library.
 * A single Book record tracks how many total and available copies exist.
 */
public class Book {

    private String id;
    private String title;
    private String author;
    private String isbn;
    private String category;
    private int totalCopies;
    private int availableCopies;

    public Book(String id, String title, String author, String isbn,
                String category, int totalCopies, int availableCopies) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.category = category;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public int getTotalCopies() { return totalCopies; }
    public void setTotalCopies(int totalCopies) { this.totalCopies = totalCopies; }
    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) { this.availableCopies = availableCopies; }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    /** Serializes this record to a single CSV line. Commas in fields are escaped. */
    public String toCsv() {
        return String.join(",",
                escape(id), escape(title), escape(author), escape(isbn),
                escape(category), String.valueOf(totalCopies), String.valueOf(availableCopies));
    }

    public static Book fromCsv(String line) {
        String[] p = splitCsv(line);
        return new Book(p[0], p[1], p[2], p[3], p[4],
                Integer.parseInt(p[5]), Integer.parseInt(p[6]));
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace(",", ";");
    }

    private static String[] splitCsv(String line) {
        return line.split(",", -1);
    }

    @Override
    public String toString() {
        return String.format("[%s] \"%s\" by %s | ISBN:%s | Category:%s | Available:%d/%d",
                id, title, author, isbn, category, availableCopies, totalCopies);
    }
}

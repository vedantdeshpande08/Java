package com.library.model;

/**
 * Lifecycle states of a book-loan transaction.
 */
public enum TransactionStatus {
    ISSUED,
    RETURNED,
    OVERDUE
}

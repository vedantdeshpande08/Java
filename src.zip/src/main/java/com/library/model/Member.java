package com.library.model;

/**
 * Represents a library member who can borrow books.
 */
public class Member {

    private String id;
    private String name;
    private String email;
    private String phone;
    private String joinDate;
    private boolean active;

    public Member(String id, String name, String email, String phone,
                  String joinDate, boolean active) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.joinDate = joinDate;
        this.active = active;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getJoinDate() { return joinDate; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public String toCsv() {
        return String.join(",",
                escape(id), escape(name), escape(email), escape(phone),
                escape(joinDate), String.valueOf(active));
    }

    public static Member fromCsv(String line) {
        String[] p = line.split(",", -1);
        return new Member(p[0], p[1], p[2], p[3], p[4], Boolean.parseBoolean(p[5]));
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace(",", ";");
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %s | %s | Joined:%s | %s",
                id, name, email, phone, joinDate, active ? "ACTIVE" : "INACTIVE");
    }
}

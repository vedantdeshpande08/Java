package com.library.util;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generates simple, human-readable sequential IDs with a type prefix
 * (e.g. BK0001, MB0002, TX0003). The starting counter can be seeded
 * from records already loaded from disk so IDs stay unique across runs.
 */
public class IdGenerator {

    private final String prefix;
    private final AtomicInteger counter;

    public IdGenerator(String prefix, int startFrom) {
        this.prefix = prefix;
        this.counter = new AtomicInteger(startFrom);
    }

    public String next() {
        return String.format("%s%04d", prefix, counter.incrementAndGet());
    }
}

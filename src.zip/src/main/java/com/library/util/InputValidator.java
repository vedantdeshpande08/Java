package com.library.util;

import com.library.exception.BusinessRuleException;

import java.util.regex.Pattern;

/**
 * Centralized input validation. Keeping these checks in one place
 * (rather than scattered across the CLI) is what lets every service
 * enforce the same rules consistently -- part of the non-functional
 * "security / data integrity" requirement.
 */
public final class InputValidator {

    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE = Pattern.compile("^[0-9+\\-() ]{7,15}$");

    private InputValidator() { }

    public static void requireNonBlank(String value, String fieldName) throws BusinessRuleException {
        if (value == null || value.trim().isEmpty()) {
            throw new BusinessRuleException(fieldName + " cannot be empty.");
        }
        if (value.contains(",")) {
            throw new BusinessRuleException(fieldName + " cannot contain a comma (reserved for storage).");
        }
    }

    public static void requireEmail(String email) throws BusinessRuleException {
        requireNonBlank(email, "Email");
        if (!EMAIL.matcher(email).matches()) {
            throw new BusinessRuleException("Email format is invalid: " + email);
        }
    }

    public static void requirePhone(String phone) throws BusinessRuleException {
        requireNonBlank(phone, "Phone");
        if (!PHONE.matcher(phone).matches()) {
            throw new BusinessRuleException("Phone format is invalid: " + phone);
        }
    }

    public static void requirePositive(int value, String fieldName) throws BusinessRuleException {
        if (value <= 0) {
            throw new BusinessRuleException(fieldName + " must be a positive number.");
        }
    }

    public static int parsePositiveInt(String raw, String fieldName) throws BusinessRuleException {
        try {
            int value = Integer.parseInt(raw.trim());
            requirePositive(value, fieldName);
            return value;
        } catch (NumberFormatException e) {
            throw new BusinessRuleException(fieldName + " must be a whole number.");
        }
    }
}

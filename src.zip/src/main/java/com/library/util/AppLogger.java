package com.library.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Minimal, dependency-free logging utility.
 * Writes timestamped lines to logs/app.log and never throws:
 * a logging failure must never crash the application.
 */
public final class AppLogger {

    private static final String LOG_DIR = "logs";
    private static final String LOG_FILE = LOG_DIR + "/app.log";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private AppLogger() { }

    public static void info(String message) {
        write("INFO", message);
    }

    public static void warn(String message) {
        write("WARN", message);
    }

    public static void error(String message) {
        write("ERROR", message);
    }

    private static void write(String level, String message) {
        try {
            java.io.File dir = new java.io.File(LOG_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            try (PrintWriter out = new PrintWriter(new FileWriter(LOG_FILE, true))) {
                out.println("[" + LocalDateTime.now().format(FMT) + "] [" + level + "] " + message);
            }
        } catch (IOException e) {
            // Logging must be best-effort only; fall back to stderr so the app keeps running.
            System.err.println("Logging failed: " + e.getMessage());
        }
    }
}

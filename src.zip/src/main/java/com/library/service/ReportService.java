package com.library.service;

import com.library.model.Book;
import com.library.model.Transaction;
import com.library.model.TransactionStatus;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Reporting / analytics on top of the three core modules.
 * Kept as its own service to keep BookService/TransactionService
 * focused purely on CRUD + business rules (single-responsibility).
 */
public class ReportService {

    private final BookService bookService;
    private final TransactionService transactionService;
    private final MemberService memberService;

    public ReportService(BookService bookService, TransactionService transactionService,
                          MemberService memberService) {
        this.bookService = bookService;
        this.transactionService = transactionService;
        this.memberService = memberService;
    }

    public String summary() {
        List<Book> books = bookService.listBooks();
        List<Transaction> transactions = transactionService.listAll();
        long issuedNow = transactions.stream().filter(t -> t.getStatus() == TransactionStatus.ISSUED).count();
        long overdue = transactionService.listOverdue().size();
        double totalFines = transactions.stream().mapToDouble(Transaction::getFineAmount).sum();
        int totalCopies = books.stream().mapToInt(Book::getTotalCopies).sum();
        int availableCopies = books.stream().mapToInt(Book::getAvailableCopies).sum();

        StringBuilder sb = new StringBuilder();
        sb.append("---- Library Summary Report ----\n");
        sb.append("Total titles          : ").append(books.size()).append("\n");
        sb.append("Total copies           : ").append(totalCopies).append("\n");
        sb.append("Available copies       : ").append(availableCopies).append("\n");
        sb.append("Registered members     : ").append(memberService.listMembers().size()).append("\n");
        sb.append("Books currently issued : ").append(issuedNow).append("\n");
        sb.append("Overdue transactions   : ").append(overdue).append("\n");
        sb.append("Total fines collected  : Rs.").append(String.format("%.2f", totalFines)).append("\n");
        return sb.toString();
    }

    /** Top borrowed books, most-issued first. */
    public List<Map.Entry<String, Long>> topBorrowedBooks(int limit) {
        Map<String, Long> counts = transactionService.listAll().stream()
                .collect(Collectors.groupingBy(Transaction::getBookId, Collectors.counting()));
        return counts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }
}

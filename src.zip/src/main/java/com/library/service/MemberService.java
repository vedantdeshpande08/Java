package com.library.service;

import com.library.exception.BusinessRuleException;
import com.library.exception.DuplicateEntryException;
import com.library.exception.LibraryException;
import com.library.exception.NotFoundException;
import com.library.model.Member;
import com.library.repository.MemberRepository;
import com.library.util.AppLogger;
import com.library.util.IdGenerator;
import com.library.util.InputValidator;

import java.time.LocalDate;
import java.util.List;

/**
 * Module 1: Member Management.
 * Provides CRUD operations for library members with validation and logging.
 */
public class MemberService {

    private final MemberRepository repository;
    private final IdGenerator idGenerator;

    public MemberService(MemberRepository repository) {
        this.repository = repository;
        this.idGenerator = new IdGenerator("MB", repository.count());
    }

    public Member registerMember(String name, String email, String phone) throws LibraryException {
        InputValidator.requireNonBlank(name, "Name");
        InputValidator.requireEmail(email);
        InputValidator.requirePhone(phone);

        boolean duplicateEmail = repository.findAll().stream()
                .anyMatch(m -> m.getEmail().equalsIgnoreCase(email));
        if (duplicateEmail) {
            throw new DuplicateEntryException("A member with email " + email + " already exists.");
        }

        String id = idGenerator.next();
        Member member = new Member(id, name, email, phone, LocalDate.now().toString(), true);
        repository.save(member);
        AppLogger.info("Registered member " + id + " (" + name + ")");
        return member;
    }

    public Member getMember(String id) throws NotFoundException {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Member not found: " + id));
    }

    public List<Member> listMembers() {
        return repository.findAll();
    }

    public Member updateMember(String id, String name, String email, String phone) throws LibraryException {
        Member existing = getMember(id);
        InputValidator.requireNonBlank(name, "Name");
        InputValidator.requireEmail(email);
        InputValidator.requirePhone(phone);
        existing.setName(name);
        existing.setEmail(email);
        existing.setPhone(phone);
        repository.save(existing);
        AppLogger.info("Updated member " + id);
        return existing;
    }

    public void deactivateMember(String id) throws NotFoundException {
        Member existing = getMember(id);
        existing.setActive(false);
        repository.save(existing);
        AppLogger.info("Deactivated member " + id);
    }

    public void deleteMember(String id) throws NotFoundException {
        getMember(id); // ensures it exists, throws NotFoundException otherwise
        repository.deleteById(id);
        AppLogger.info("Deleted member " + id);
    }

    public boolean exists(String id) {
        return repository.existsById(id);
    }
}

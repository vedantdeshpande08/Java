package com.library.service;

import com.library.exception.BusinessRuleException;
import com.library.exception.LibraryException;
import com.library.exception.NotFoundException;
import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;
import com.library.model.TransactionStatus;
import com.library.repository.TransactionRepository;
import com.library.util.AppLogger;
import com.library.util.IdGenerator;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Module 3: Transaction Management (issue / return / fine calculation).
 * Coordinates BookService and MemberService to enforce the core
 * business rules: a book can only be issued if a copy is available,
 * and returning late accrues a fine.
 */
public class TransactionService {

    private static final int LOAN_PERIOD_DAYS = 14;
    private static final double FINE_PER_DAY = 5.0; // in rupees

    private final TransactionRepository repository;
    private final BookService bookService;
    private final MemberService memberService;
    private final IdGenerator idGenerator;

    public TransactionService(TransactionRepository repository, BookService bookService,
                               MemberService memberService) {
        this.repository = repository;
        this.bookService = bookService;
        this.memberService = memberService;
        this.idGenerator = new IdGenerator("TX", repository.count());
    }

    public Transaction issueBook(String bookId, String memberId) throws LibraryException {
        Book book = bookService.getBook(bookId);
        Member member = memberService.getMember(memberId);

        if (!member.isActive()) {
            throw new BusinessRuleException("Member " + memberId + " is not active.");
        }
        if (!book.isAvailable()) {
            throw new BusinessRuleException("No available copies of \"" + book.getTitle() + "\" to issue.");
        }

        LocalDate issueDate = LocalDate.now();
        LocalDate dueDate = issueDate.plusDays(LOAN_PERIOD_DAYS);
        String id = idGenerator.next();
        Transaction transaction = new Transaction(id, bookId, memberId, issueDate, dueDate,
                null, 0.0, TransactionStatus.ISSUED);

        repository.save(transaction);
        bookService.decrementAvailable(book);
        AppLogger.info("Issued book " + bookId + " to member " + memberId + " (txn " + id + ")");
        return transaction;
    }

    public Transaction returnBook(String transactionId) throws LibraryException {
        Transaction transaction = repository.findById(transactionId)
                .orElseThrow(() -> new NotFoundException("Transaction not found: " + transactionId));

        if (transaction.getStatus() == TransactionStatus.RETURNED) {
            throw new BusinessRuleException("Transaction " + transactionId + " is already returned.");
        }

        LocalDate returnDate = LocalDate.now();
        long overdueDays = ChronoUnit.DAYS.between(transaction.getDueDate(), returnDate);
        double fine = overdueDays > 0 ? overdueDays * FINE_PER_DAY : 0.0;

        transaction.setReturnDate(returnDate);
        transaction.setFineAmount(fine);
        transaction.setStatus(TransactionStatus.RETURNED);
        repository.save(transaction);

        Book book = bookService.getBook(transaction.getBookId());
        bookService.incrementAvailable(book);

        AppLogger.info("Returned book " + transaction.getBookId() + " (txn " + transactionId
                + "), fine: Rs." + fine);
        return transaction;
    }

    public List<Transaction> listAll() {
        return repository.findAll();
    }

    public List<Transaction> listByMember(String memberId) {
        return repository.findByMemberId(memberId);
    }

    public List<Transaction> listOverdue() {
        LocalDate today = LocalDate.now();
        return repository.findAll().stream()
                .filter(t -> t.getStatus() == TransactionStatus.ISSUED && t.getDueDate().isBefore(today))
                .toList();
    }
}

package com.library.service;

import com.library.exception.LibraryException;
import com.library.exception.NotFoundException;
import com.library.model.Book;
import com.library.repository.BookRepository;
import com.library.util.AppLogger;
import com.library.util.IdGenerator;
import com.library.util.InputValidator;

import java.util.List;

/**
 * Module 2: Book / Inventory Management.
 * Provides CRUD operations for the book catalogue, tracking total vs
 * available copies so the Transaction module can safely issue/return books.
 */
public class BookService {

    private final BookRepository repository;
    private final IdGenerator idGenerator;

    public BookService(BookRepository repository) {
        this.repository = repository;
        this.idGenerator = new IdGenerator("BK", repository.count());
    }

    public Book addBook(String title, String author, String isbn, String category, int copies)
            throws LibraryException {
        InputValidator.requireNonBlank(title, "Title");
        InputValidator.requireNonBlank(author, "Author");
        InputValidator.requireNonBlank(isbn, "ISBN");
        InputValidator.requireNonBlank(category, "Category");
        InputValidator.requirePositive(copies, "Copies");

        String id = idGenerator.next();
        Book book = new Book(id, title, author, isbn, category, copies, copies);
        repository.save(book);
        AppLogger.info("Added book " + id + " (" + title + ") with " + copies + " copies");
        return book;
    }

    public Book getBook(String id) throws NotFoundException {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Book not found: " + id));
    }

    public List<Book> listBooks() {
        return repository.findAll();
    }

    public List<Book> searchByTitleOrAuthor(String keyword) {
        String needle = keyword.toLowerCase();
        return repository.findAll().stream()
                .filter(b -> b.getTitle().toLowerCase().contains(needle)
                        || b.getAuthor().toLowerCase().contains(needle))
                .toList();
    }

    public Book updateBook(String id, String title, String author, String isbn, String category)
            throws LibraryException {
        Book existing = getBook(id);
        InputValidator.requireNonBlank(title, "Title");
        InputValidator.requireNonBlank(author, "Author");
        InputValidator.requireNonBlank(isbn, "ISBN");
        InputValidator.requireNonBlank(category, "Category");
        existing.setTitle(title);
        existing.setAuthor(author);
        existing.setIsbn(isbn);
        existing.setCategory(category);
        repository.save(existing);
        AppLogger.info("Updated book " + id);
        return existing;
    }

    public void addCopies(String id, int extraCopies) throws LibraryException {
        InputValidator.requirePositive(extraCopies, "Copies");
        Book existing = getBook(id);
        existing.setTotalCopies(existing.getTotalCopies() + extraCopies);
        existing.setAvailableCopies(existing.getAvailableCopies() + extraCopies);
        repository.save(existing);
        AppLogger.info("Added " + extraCopies + " copies to book " + id);
    }

    public void deleteBook(String id) throws NotFoundException {
        getBook(id);
        repository.deleteById(id);
        AppLogger.info("Deleted book " + id);
    }

    // Package-visible helpers used by TransactionService to adjust availability.
    void decrementAvailable(Book book) {
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        repository.save(book);
    }

    void incrementAvailable(Book book) {
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        repository.save(book);
    }
}

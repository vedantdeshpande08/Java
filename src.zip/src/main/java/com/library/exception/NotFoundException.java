package com.library.exception;

/** Thrown when a lookup by ID does not match any stored record. */
public class NotFoundException extends LibraryException {
    public NotFoundException(String message) {
        super(message);
    }
}

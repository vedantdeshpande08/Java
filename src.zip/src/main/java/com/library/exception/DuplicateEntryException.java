package com.library.exception;

/** Thrown when an attempt is made to create a record with an ID that already exists. */
public class DuplicateEntryException extends LibraryException {
    public DuplicateEntryException(String message) {
        super(message);
    }
}

package com.library.exception;

/**
 * Base checked exception for all domain-level failures in the application.
 * Using a checked exception forces callers (the CLI layer) to handle
 * failures explicitly instead of letting the program crash.
 */
public class LibraryException extends Exception {
    public LibraryException(String message) {
        super(message);
    }
}

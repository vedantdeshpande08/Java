package com.library.exception;

/** Thrown when an operation violates a domain rule (e.g. no copies available, invalid input). */
public class BusinessRuleException extends LibraryException {
    public BusinessRuleException(String message) {
        super(message);
    }
}

package com.library;

import com.library.exception.BusinessRuleException;
import com.library.exception.LibraryException;
import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;
import com.library.repository.BookRepository;
import com.library.repository.MemberRepository;
import com.library.repository.TransactionRepository;
import com.library.service.BookService;
import com.library.service.MemberService;
import com.library.service.TransactionService;

import java.io.File;

/**
 * Dependency-free validation/unit tests for the core services.
 * Deliberately avoids JUnit so the project can be built and tested
 * with nothing but the JDK (javac/java) -- no internet access needed
 * to fetch a test framework.
 *
 * Run with:  java -cp out com.library.SimpleTestRunner
 */
public class SimpleTestRunner {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) throws Exception {
        // Use an isolated, disposable data directory so tests never touch real app data.
        String testDataDir = "test-data";
        cleanUp(testDataDir);

        BookRepository bookRepo = new BookRepository(testDataDir + "/books.csv");
        MemberRepository memberRepo = new MemberRepository(testDataDir + "/members.csv");
        TransactionRepository txnRepo = new TransactionRepository(testDataDir + "/transactions.csv");

        BookService bookService = new BookService(bookRepo);
        MemberService memberService = new MemberService(memberRepo);
        TransactionService txnService = new TransactionService(txnRepo, bookService, memberService);

        testAddBookAndRetrieve(bookService);
        testDuplicateEmailRejected(memberService);
        testInvalidEmailRejected(memberService);
        testIssueAndReturnBook(bookService, memberService, txnService);
        testCannotIssueWhenNoCopiesLeft(bookService, memberService, txnService);
        testCannotIssueToInactiveMember(bookService, memberService, txnService);

        cleanUp(testDataDir);

        System.out.println("\n===================================");
        System.out.println("Tests passed: " + passed + ", failed: " + failed);
        System.out.println("===================================");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void testAddBookAndRetrieve(BookService bookService) {
        try {
            Book b = bookService.addBook("Clean Code", "Robert C. Martin", "ISBN001", "Software", 3);
            Book fetched = bookService.getBook(b.getId());
            check("addBook + getBook round-trip", fetched.getTitle().equals("Clean Code")
                    && fetched.getAvailableCopies() == 3);
        } catch (Exception e) {
            fail("testAddBookAndRetrieve threw: " + e);
        }
    }

    private static void testDuplicateEmailRejected(MemberService memberService) {
        try {
            memberService.registerMember("Alice", "alice@example.com", "9990001111");
            try {
                memberService.registerMember("Alice2", "alice@example.com", "9990002222");
                fail("Expected DuplicateEntryException for repeated email");
            } catch (LibraryException expected) {
                check("duplicate email rejected", true);
            }
        } catch (Exception e) {
            fail("testDuplicateEmailRejected threw: " + e);
        }
    }

    private static void testInvalidEmailRejected(MemberService memberService) {
        try {
            memberService.registerMember("Bob", "not-an-email", "9990003333");
            fail("Expected BusinessRuleException for invalid email");
        } catch (BusinessRuleException expected) {
            check("invalid email rejected", true);
        } catch (Exception e) {
            fail("testInvalidEmailRejected threw wrong exception type: " + e);
        }
    }

    private static void testIssueAndReturnBook(BookService bookService, MemberService memberService,
                                                TransactionService txnService) {
        try {
            Book book = bookService.addBook("The Pragmatic Programmer", "Hunt & Thomas", "ISBN002", "Software", 1);
            Member member = memberService.registerMember("Carol", "carol@example.com", "9990004444");

            Transaction issued = txnService.issueBook(book.getId(), member.getId());
            check("book unavailable after issue", !bookService.getBook(book.getId()).isAvailable());

            Transaction returned = txnService.returnBook(issued.getId());
            check("book available after return", bookService.getBook(book.getId()).isAvailable());
            check("no fine for on-time return", returned.getFineAmount() == 0.0);
        } catch (Exception e) {
            fail("testIssueAndReturnBook threw: " + e);
        }
    }

    private static void testCannotIssueWhenNoCopiesLeft(BookService bookService, MemberService memberService,
                                                          TransactionService txnService) {
        try {
            Book book = bookService.addBook("Limited Copy Book", "Author X", "ISBN003", "Fiction", 1);
            Member m1 = memberService.registerMember("Dave", "dave@example.com", "9990005555");
            Member m2 = memberService.registerMember("Erin", "erin@example.com", "9990006666");

            txnService.issueBook(book.getId(), m1.getId());
            try {
                txnService.issueBook(book.getId(), m2.getId());
                fail("Expected BusinessRuleException when no copies remain");
            } catch (BusinessRuleException expected) {
                check("issue blocked when no copies available", true);
            }
        } catch (Exception e) {
            fail("testCannotIssueWhenNoCopiesLeft threw: " + e);
        }
    }

    private static void testCannotIssueToInactiveMember(BookService bookService, MemberService memberService,
                                                          TransactionService txnService) {
        try {
            Book book = bookService.addBook("Another Book", "Author Y", "ISBN004", "Fiction", 2);
            Member member = memberService.registerMember("Frank", "frank@example.com", "9990007777");
            memberService.deactivateMember(member.getId());

            try {
                txnService.issueBook(book.getId(), member.getId());
                fail("Expected BusinessRuleException for inactive member");
            } catch (BusinessRuleException expected) {
                check("issue blocked for inactive member", true);
            }
        } catch (Exception e) {
            fail("testCannotIssueToInactiveMember threw: " + e);
        }
    }

    private static void check(String description, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("[PASS] " + description);
        } else {
            failed++;
            System.out.println("[FAIL] " + description);
        }
    }

    private static void fail(String description) {
        failed++;
        System.out.println("[FAIL] " + description);
    }

    private static void cleanUp(String dir) {
        File folder = new File(dir);
        if (folder.exists()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File f : files) f.delete();
            }
            folder.delete();
        }
    }
}
